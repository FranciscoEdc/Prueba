function iniciar() {
    var usuario = document.getElementById("usuario");
    var clave = document.getElementById("clave");

    if (usuario.value=="jose" && clave.value==1234) {
        document.getElementById("sesion").innerHTML = "usuario correcto";
        document.getElementById("sesion").style.color = "green";
    } else {
        document.getElementById("sesion").innerHTML = "usuario erroneo";
        document.getElementById("sesion").style.color = "red";
    }
}
function continuar() {
    document.getElementById("adicional").classList.remove("oculto");
    document.getElementById("adicional").classList.add("visible");
}

function clonar() {
    var texto = document.getElementById("texto").innerHTML;
    document.getElementById("clon").innerHTML = texto;
}

function nota() {
    var nota = document.getElementById("numero");

    if (nota.value < 3) {
        document.getElementById("nota").innerHTML = "Muy deficiente.";
    } else {
        if (nota.value < 5) {
            document.getElementById("nota").innerHTML = "Deficiente.";
        } else {
            if (nota.value < 7) {
                document.getElementById("nota").innerHTML = "Bien";
            } else {
                if (nota.value < 9) {
                    document.getElementById("nota").innerHTML = "Notable";
                } else {
                    document.getElementById("nota").innerHTML = "Sobresaliente";
                }
            }
        }
    }
}